const express = require("express");
const admin = require("firebase-admin");
const serviceAccount = require("./vaaniai-firebase-key.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.send("VaaniAI Backend is Live!");
});

// Example protected route
app.post("/save-email", async (req, res) => {
  try {
    const { email } = req.body;
    const db = admin.firestore();
    await db.collection("emails").add({ email, createdAt: new Date() });
    res.status(200).send({ message: "Email saved!" });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

